package com.capg.bean;

public class Transaction {
	int transid;
	Long frmAc;
	Long toAc;
	Long oldBal;
	Long newBal;
	String TransType;

	public int getTransid() {
		return transid;
	}

	public void setTransid(int transid) {
		this.transid = transid;
	}

	public Long getFrmAc() {
		return frmAc;
	}

	@Override
	public String toString() {
		return "Transaction [transid=" + transid + ", frmAc=" + frmAc + ", toAc=" + toAc + ", oldBal=" + oldBal
				+ ", newBal=" + newBal + ", TransType=" + TransType + "]";
	}

	public void setFrmAc(Long frmAc) {
		this.frmAc = frmAc;
	}

	public Long getToAc() {
		return toAc;
	}

	public void setToAc(Long toAc) {
		this.toAc = toAc;
	}

	public Long getOldBal() {
		return oldBal;
	}

	public void setOldBal(Long oldBal) {
		this.oldBal = oldBal;
	}

	public Long getNewBal() {
		return newBal;
	}

	public void setNewBal(Long newBal) {
		this.newBal = newBal;
	}

	public String getTransType() {
		return TransType;
	}

	public void setTransType(String transType) {
		TransType = transType;
	}

}