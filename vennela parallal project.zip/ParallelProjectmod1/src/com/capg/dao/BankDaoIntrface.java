package com.capg.dao;

import java.util.List;

import com.capg.bean.AccountDet;
import com.capg.bean.Transaction;

public interface BankDaoIntrface {

	long insertAccount(AccountDet account);

	AccountDet retriveAccount(Long acc);

	AccountDet depositMoney(Long acc2, Long depositAmt);

	AccountDet withdrawMoney(Long accno3, Long withdrawAmt);

	AccountDet transfer(Long sender, Long receiver, Long amt);

	List<Transaction> printTransaction();

}
