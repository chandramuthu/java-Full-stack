package usrDefExptns;

@SuppressWarnings("serial")
public class AccountNotFoundException extends RuntimeException {
	public AccountNotFoundException(String errMsg) {
		super(errMsg);
	}
}
