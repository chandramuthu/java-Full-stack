package capg.dao;

import java.util.HashMap;
import java.util.Map;

import capg.bean.MobileApp;
import usrDefExptns.AccountNotFoundException;

public class MobdaoClas implements MobdaoIntrface {
	Map<String, MobileApp> accountEntry;

	public MobdaoClas() {
		accountEntry = new HashMap<>();
		accountEntry.put("9123456780", new MobileApp("Prepaid", "ven", 200));
		accountEntry.put("9658935913", new MobileApp("Prepaid", "ved", 500));
		accountEntry.put("8965263257", new MobileApp("Prepaid", "meg", 100));
		accountEntry.put("7829685996", new MobileApp("Prepaid", "kee", 300));
		accountEntry.put("6698752146", new MobileApp("Prepaid", "vij", 50));

	}

	@Override
	public MobileApp getAccountDetails(String mobileNo) {
		MobileApp account = accountEntry.get(mobileNo);
		if (account == null) {
			throw new AccountNotFoundException("ERROR: Given account does not Exists");
		}

		return account;
	}

	@Override
	public MobileApp rechargeAccount(String mobileNo1, double rechargeAmount) {
		MobileApp account = accountEntry.get(mobileNo1);
		if (account == null) {
			throw new AccountNotFoundException("ERROR:Cannot Recharge Account, Given Mobile Number doesnot exist");
		}
		double a = account.getAccountBalance();
		a += rechargeAmount;
		account.setAccountBalance(a);
		return account;
	}

}