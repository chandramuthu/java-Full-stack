package capg.service;

import capg.bean.MobileApp;
import capg.dao.MobdaoClas;
import capg.dao.MobdaoIntrface;

public class MobserviceClas implements MobdaoIntrface {
	MobdaoIntrface dao = new MobdaoClas();

	@Override
	public MobileApp getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public MobileApp rechargeAccount(String mobileNo1, double rechargeAmount) {
		// TODO Auto-generated method stub
		return dao.rechargeAccount(mobileNo1, rechargeAmount);
	}

	
}
