package Module1;

import java.util.Scanner;

public class Ex1 {
	int sum=0;
	int CalculateSum(int num)
	{
		for(int i=0;i<=num;i++)
		{
			if((i%3==0) || (i%5==0))
			{
				sum=sum+i;
			}
		}
		return sum;
	}
public static void main(String[] args) {
	Ex1 e=new Ex1();
	Scanner s = new Scanner(System.in);
	System.out.print("Enter an number: ");
	int z = s.nextInt();
	System.out.println("Total sum of N numbers which is divisible by either 3 or 5 is: "+(e.CalculateSum(z)));
	s.close();
}
}
