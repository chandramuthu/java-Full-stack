package java8;

import java.util.Comparator;
import java.util.TreeMap;

public class FunctionalInterfaceInTreeMap {
	public static void main(String[] args) {
		
	
Comparator<Integer> c=(i1,i2)->{return (i1<i2)?1:(i1>i2)?-1:0;};
TreeMap<Integer, String> tm=new TreeMap<Integer,String>(c);
tm.put(200,"dfge");
tm.put(564,"fdfsf");
System.out.println(tm);

}
}