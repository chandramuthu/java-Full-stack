package java8;

interface A

{
	void m1();
	default void m2()
	{
		System.out.println("Interface Default method");
	}
}
public class defaultFunctionalInterface implements A {

	@Override
	public void m1()
	{
		System.out.println("Overrided m1 method!!");
	}
	
	public void m2()
	{
		System.out.println("Overrided m2 method!!");
	}
	public static void main(String[] args) {
		defaultFunctionalInterface td=new defaultFunctionalInterface();
		td.m1();
		td.m2();
}


}
