
class Test12
{  
void m1()
{
	int i=1111111111;
	System.out.println("eating...");
	
	}  
}  

class Test123 extends Test12
{  
void m5()
{
	int i=1111111111;
	System.out.println("eating 123...");
	
	}  
}  
class Test24 extends Test12
{  
void m2()
{
	int i=2222222;
	System.out.println("sleeping...");

	}  
} 

class Heirarchical extends Test12
{ 
	public static void main(String args[])
	{  
		Heirarchical d=new Heirarchical(); 
		d.m1();
		Test24 t=new Test24();
		t.m2();
		t.m1();
		System.out.println("Heirarchical Inheritance");
		Test123 t1=new Test123();
		t1.m5();
		
	}
}