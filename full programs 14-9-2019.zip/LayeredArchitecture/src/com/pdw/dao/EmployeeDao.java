package com.pdw.dao;

import com.pdw.bean.Employee;

public interface EmployeeDao {

Employee insertEmployee(Employee employee);
Employee retrieveEmployee(Integer eid);
}
