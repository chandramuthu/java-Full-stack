package com.pdw.ui;

import java.util.Scanner;

import com.pdw.bean.Employee;
import com.pdw.service.EmployeeService;
import com.pdw.service.EmployeeServiceImpl;

public class MainUi {
	static EmployeeService service=new EmployeeServiceImpl(); 
	static Scanner scanner =new Scanner(System.in);

public static void main(String[] args) {
	while(true)
	{
		System.out.println("Welcome to the Application");
		System.out.println("****************************");
		System.out.println("1. Insert Element");
		System.out.println("2. Fetch Element");
		System.out.println("3. Exit");
		System.out.println("Enter your Choice");
		int option=scanner.nextInt();
		switch (option) {
		case 1:
			System.out.println("Enter Your ID : ");
			int empId=scanner.nextInt();
			System.out.println("Enter Your Name : ");
			String empName=scanner.next();
			System.out.println("Enter Your Salary : ");
			int empSal=scanner.nextInt();
			Employee employee=new Employee();
			Employee employee1=new Employee();
			employee1.setEmpName(empName);
			employee1.setEmpId(empId);
			employee1.setEmpSal(empSal);
			service.insertEmployee(employee1);
			System.out.println("Employee Details Inserted *****************");
			
			break;
		case 2:
			System.out.println("Enter Your ID : ");
			int empId1=scanner.nextInt();
			
			Employee emp=service.retrieveEmployee(empId1);
			System.out.println(emp);
		System.out.println("Data Retrieved");
		break;
		case 3:
			System.out.println("Thank You");
			System.exit(0);
			break;
		default: 
			System.out.println("Wrong Choice!!!!!!");
		}
	}
}
}

