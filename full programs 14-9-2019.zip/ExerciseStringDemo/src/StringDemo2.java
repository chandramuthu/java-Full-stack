
public class StringDemo2 {
public static void main(String[] args) {
	{
		String str="java standard edition";
		String s1= str.substring(0,1).toUpperCase()+str.substring(1).toLowerCase();
		System.out.println(s1);
	}

}
}
