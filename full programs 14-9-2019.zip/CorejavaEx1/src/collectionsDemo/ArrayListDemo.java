package collectionsDemo;

import java.util.ArrayList;

public class ArrayListDemo {
public static void main(String[] args) {
	ArrayList a=new ArrayList();// default value is 10--->16---->25
	//cc*(3/2)+1
	a.add(10);
	a.add(20);
	a.add("chandru");
	a.add("Vijay");
	a.add("Vijay");
	a.add("Vijay");
	a.add("Vijay");
	a.add('c');
	a.add(true);
	a.add(20);
	a.add("chandru");
	a.add("Vijay");
	a.add("Vijay");
	a.add("Vijay");
	a.add("Vijay");
	a.add('c');
	a.add(true);
	System.out.println(a);
	System.out.println(a);
}
}
