package collectionsDemo;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {
	public static void main(String[] args) {
		LinkedHashSet h= new LinkedHashSet();
		h.add(10);
		h.add("asfsafs");
		h.add("gdghfghf");
		h.add('c');
		System.out.println(h);
	}
}
