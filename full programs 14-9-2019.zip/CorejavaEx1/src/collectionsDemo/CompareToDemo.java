package collectionsDemo;

public class CompareToDemo {
public static void main(String[] args) {
	System.out.println("c".compareTo("a")); //obj1 compareTo obj2
	System.out.println("b".compareTo("z"));
	System.out.println("s".compareTo("x"));
	System.out.println("v".compareTo("y"));
}
}


//- if ob
//+
//0