
public class CommandLine {
public static void main(String[] args) {
	int a=Integ
}
}
