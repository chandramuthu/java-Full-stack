
public class TryCatchDemo2 {
public static void main(String[] args) {
	int i=0;
	i = i++ + i;
	System.out.println("hi"+i);
	
}
}
