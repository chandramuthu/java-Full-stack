import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router'
import { EmployeeComponent } from './employee/employee.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';

const routes: Routes =[

  {
    path:'',
    component:EmployeeComponent
      },
  {
path:'Add-Employee',
component:EmployeeComponent
  },
  {
    path:'update-Employee',
    component:EmployeeComponent
      },
  {
    path:'Display-Employee',
component:EmployeelistComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  
})

export class AddemployeeModule { }
