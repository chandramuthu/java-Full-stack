import { DisplayemployeeModule } from './displayemployee.module';

describe('DisplayemployeeModule', () => {
  let displayemployeeModule: DisplayemployeeModule;

  beforeEach(() => {
    displayemployeeModule = new DisplayemployeeModule();
  });

  it('should create an instance', () => {
    expect(displayemployeeModule).toBeTruthy();
  });
});
