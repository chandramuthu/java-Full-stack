import { Component, OnInit } from '@angular/core';
import { Employee, MyserviceService } from '../myservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
createdEmployee:Employee;
createdFlag:boolean=false;
service:MyserviceService;

  constructor(service:MyserviceService,private router:Router) { 
this.service=service;

  }

  ngOnInit() {
    
  }
  pushemployee(data:any)
  {
    this.createdEmployee=new Employee(data.eid,data.ename)
    this.service.pushemployee(this.createdEmployee);
  this.router.navigateByUrl("Add-Employee");

  }

}
