import { AddemployeeModule } from './addemployee.module';

describe('AddemployeeModule', () => {
  let addemployeeModule: AddemployeeModule;

  beforeEach(() => {
    addemployeeModule = new AddemployeeModule();
  });

  it('should create an instance', () => {
    expect(addemployeeModule).toBeTruthy();
  });
});
