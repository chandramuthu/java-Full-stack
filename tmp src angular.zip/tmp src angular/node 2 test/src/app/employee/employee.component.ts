import { Component, OnInit } from '@angular/core';
import { Employee,MyserviceService } from'../myservice.service';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  service:MyserviceService
  constructor( service:MyserviceService) {
    this.service=service
   }
   Employees:Employee[]=[]
  ngOnInit() {
    
this.service.fetchEmployees();
this.Employees=this.service.getEmployees();

  }
delete(eid:number)
{
  this.service.delete(eid);
}

}


