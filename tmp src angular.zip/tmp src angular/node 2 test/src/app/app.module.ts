import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { AddemployeeModule } from './addemployee.module';
import { DisplayemployeeModule } from './displayemployee.module';
import { HttpClient,HttpClientModule } from '../../node_modules/@angular/common/http';
import { MyserviceService } from './myservice.service';
import { UpdateEmpComponent } from './update-emp/update-emp.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    EmployeelistComponent,
    UpdateEmpComponent
  ],
  imports: [
    BrowserModule,
    AddemployeeModule,
    FormsModule,
    DisplayemployeeModule,
    HttpClientModule,
    
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
