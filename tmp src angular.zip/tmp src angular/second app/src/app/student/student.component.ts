import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
student:any[];
  constructor() {  
    
  }

  ngOnInit() {
    this.student=[
      {id:1, name:"chandru", dept:"cs"},
      {id:2, name:"Swathi", dept:"cs"},
      {id:3, name:"Abith", dept:"cs"},
      {id:4, name:"bhavya", dept:"cs"},
      {id:5, name:"lavanya", dept:"cs"}
     ];
  }

}
