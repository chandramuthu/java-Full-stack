import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router'
import { EmployeeComponent } from './employee/employee.component';
import { StudentComponent } from './student/student.component';
import { ExitComponent } from './exit/exit.component';

const routes: Routes =[

  {
path:'list-employee',
component:EmployeeComponent
  },
  {
    path:'list-student',
component:StudentComponent
  },
  {
    path:'exit',
component:ExitComponent
  }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  
})
export class AppRoutingModule { }
