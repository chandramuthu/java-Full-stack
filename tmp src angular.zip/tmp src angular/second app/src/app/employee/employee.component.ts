import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

 
    emp: any[];
    constructor(){
      this.emp=[
      {eid:1, ename:"chandru", esal:10000},
      {eid:2, ename:"Swathi", esal:20000},
      {eid:3, ename:"Abith", esal:30000},
      {eid:4, ename:"bhavya", esal:40000},
      {eid:5, ename:"lavanya", esal:50000}
     ];
  }
  

  ngOnInit() {
  }

}
