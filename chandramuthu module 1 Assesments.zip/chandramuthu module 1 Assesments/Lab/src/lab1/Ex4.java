package lab1;

import java.util.Scanner;

public class Ex4 {
	int fla=1;
	void Calculate(int num)
	{
		while(num>1)
		{
			if(num%2==1){
		
				System.out.println("the Value is not the sqare root of 2");
				fla=0;
				break;
			}
			num=num/2;
		}
		if(fla==1)
		{
			System.out.println("It is a Square root");
		
		}
	}
	
	public static void main(String[] args) {
		Ex4 e=new Ex4();
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter Any Number to find whether the given number is Square of two or not.");
				int n=sc.nextInt();
				e.Calculate(n);
				sc.close();
	}

}
