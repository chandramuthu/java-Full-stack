package lab1;
import java.util.Scanner;
public class Ex2 {
	long CalculateDifference(int n)
	{
		long sum=0;
		long total=0;
		for(int i=0;i<=n;i++)
		{
			int h=i*i;
			sum=sum+h;
			total=total+i;
		}
		total=total*total;
		long Ans=sum-total;
		return Ans;
	}
public static void main(String[] args) {
	Ex2 e=new Ex2();
	Scanner s = new Scanner(System.in);
	System.out.print("Enter an number: ");
	int num = s.nextInt();
	System.out.println("sum="+e.CalculateDifference(num));
	s.close();
}
}