package lab1;

import java.util.Scanner;

public class Ex3 {
	int flags=0;
	void checkNumber(int num)
	{
		while(num>0)
		{
		int div=num/10;
		int rem1=num%10;
		int rem2=div%10;
		num=num/10;
		if(rem1<=rem2)
		{
			flags=1;
			break;
		}
		
		}	
	if(flags==1)
	{
		System.out.println("The number is in Incresing order only.");
	}
	else
	{
		System.out.println("The number is not in Incresing order");
	}
	
	}
public static void main(String[] args) {
	Ex3 e=new Ex3();
	Scanner s = new Scanner(System.in);
	System.out.print("Enter an number: ");
	int z = s.nextInt();
	e.checkNumber(z);
	s.close();
}
}
