package com.cg.eis.exception;

public abstract class EmployeeException implements Runnable {

	public char[] getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
