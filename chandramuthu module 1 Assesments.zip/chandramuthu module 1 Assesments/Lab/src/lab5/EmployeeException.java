package lab5;


	@SuppressWarnings("serial")
	public class EmployeeException extends Exception {
	    
	    public EmployeeException(String Str) 
	       { 
	           super(Str); 
	       } 
	}

