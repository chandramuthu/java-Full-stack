package exception;
@SuppressWarnings("serial")
public class EmployeeException extends Exception {
	
    public EmployeeException(String Str) 
       { 
           super(Str); 
       } 
}