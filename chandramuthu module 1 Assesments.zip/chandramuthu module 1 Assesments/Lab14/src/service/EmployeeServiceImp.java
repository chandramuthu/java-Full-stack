package service;

import bean.Employee;

 

public class EmployeeServiceImp implements EmployeeService
{
    @Override
    public void getEmployeeDetails(int eid, String ename, int sal)
    {
        Employee e=new Employee();
        if(sal>5000 && sal< 20000)
        {
            e.setEmpDesignation("System Associate");
            e.setEmpInsuranceScheme("Scheme C");
            e.setEmpid(eid);
            e.setEmpName(ename);
            e.setEmpSalary(sal);
            System.out.println("Employee ID is "+e.getEmpid());
            System.out.println(" Name is "+e.getEmpName());
            System.out.println(" Salary is "+e.getEmpSalary());
            System.out.println(" Designation is "+e.getEmpDesignation());
            System.out.println(" Insurance scheme is "+e.getEmpInsuranceScheme());    
        }
        else if(sal>=20000 && sal<40000)
        {
            e.setEmpDesignation("Programmer");
            e.setEmpInsuranceScheme("Scheme B");
            e.setEmpid(eid);
            e.setEmpName(ename);
            e.setEmpSalary(sal);
            System.out.println("Employee ID is "+e.getEmpid());
            System.out.println(" Name is "+e.getEmpName());
            System.out.println(" Salary is "+e.getEmpSalary());
            System.out.println(" Designation is "+e.getEmpDesignation());
            System.out.println(" Insurance scheme is "+e.getEmpInsuranceScheme());
        }
        else if(sal>=40000)
        {
            e.setEmpDesignation("Manager");
            e.setEmpInsuranceScheme("Scheme A");
            e.setEmpid(eid);
            e.setEmpName(ename);
            e.setEmpSalary(sal);
            System.out.println("Employee ID is "+e.getEmpid());
            System.out.println(" Name is "+e.getEmpName());
            System.out.println(" Salary is "+e.getEmpSalary());
            System.out.println(" Designation is "+e.getEmpDesignation());
            System.out.println(" Insurance scheme is "+e.getEmpInsuranceScheme());
        }
        else if(sal<5000)
        {
            e.setEmpDesignation("Clerk");
            e.setEmpInsuranceScheme("No Scheme");
            e.setEmpid(eid);
            e.setEmpName(ename);
            e.setEmpSalary(sal);
            System.out.println("Employee ID is "+e.getEmpid());
            System.out.println(" Name is "+e.getEmpName());
            System.out.println(" Salary is "+e.getEmpSalary());
            System.out.println(" Designation is "+e.getEmpDesignation());
            System.out.println(" Insurance scheme is "+e.getEmpInsuranceScheme());
        }
        else
        {
            System.out.println("Wrong Input");
        }
        
    }
}
 