package collections;

import java.util.Comparator;

public class MyCompareto implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
