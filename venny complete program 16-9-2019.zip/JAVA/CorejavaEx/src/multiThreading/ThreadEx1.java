package multiThreading;
class Test implements Runnable
{

	@Override
	public void run() {
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Class");
		}
		
	}
	
}
public class ThreadEx1 {
	public static void main(String[] args) {
		Test test =new Test();
		Thread t=new Thread(test);
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("Parent Class");
		}
		
	}
}
