package module1;

import java.util.Scanner;

class AgeException extends Exception
{
	public AgeException(String errMsg) {
		super(errMsg);
	}
}
public class AgeValidation
{
static void check(int n) throws AgeException 
{
	if(n>15)
	{
		System.out.println("\n Validation Succesfull"+" Your Age is above 15");
	}
	else
	{
		throw new AgeException("\n Validation Unsuccessfull"+" Your Age is below 15");
	}
}

	public static void main(String[] args)throws AgeException
	{
    System.out.println("Enter your Age for Validation:");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	AgeValidation.check(n);
	sc.close();

	}

}
