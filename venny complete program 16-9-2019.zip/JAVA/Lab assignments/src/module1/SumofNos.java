package module1;

import java.util.Scanner;

public class SumofNos
{
	void calculateSum(int n)
	{
		int sum=0;
		for(int i=0;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum=sum+i;
			}
		}
	System.out.println("Sum of nos :" +sum);
	}
public static void main(String[] args) {
	SumofNos obj=new SumofNos();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number :");
	int n=sc.nextInt();
	obj.calculateSum(n);
	sc.close();
}
}
