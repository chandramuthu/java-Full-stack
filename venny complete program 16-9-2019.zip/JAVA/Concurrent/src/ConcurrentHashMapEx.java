import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapEx {
public static void main(String[] args) {
	ConcurrentHashMap cm=new ConcurrentHashMap();
	cm.put(10, "nandy");
	cm.put(20, "sam");
	cm.put(30, "pooja");
	System.out.println(cm);
	cm.putIfAbsent(20,"m" );
	/*System.out.println(cm);
	cm.remove(30,"kowsi");
	cm.replace(10, "sam", "samvitha");
	System.out.println(cm);
*/}
}
