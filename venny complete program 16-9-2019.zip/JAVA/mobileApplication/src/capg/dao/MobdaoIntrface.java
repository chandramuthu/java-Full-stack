package capg.dao;

import capg.bean.MobileApp;

public interface MobdaoIntrface {

	MobileApp getAccountDetails(String mobileNo);

	MobileApp rechargeAccount(String mobileNo1, double rechargeAmount);
}
