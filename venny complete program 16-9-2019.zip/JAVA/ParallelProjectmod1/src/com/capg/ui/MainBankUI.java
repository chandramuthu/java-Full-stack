package com.capg.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.cap.usrdefExptns.AccountNotFound;
import com.capg.bean.AccountDet;
import com.capg.bean.Transaction;
import com.capg.service.BankServiceClass;
import com.capg.service.BankServiceIntrface;

public class MainBankUI {
	static BankServiceIntrface bank = new BankServiceClass();
	static Scanner scanner = new Scanner(System.in);//take input from user

	public static void main(String[] args) {

		while (true) {

			System.out.println("Welcome to Bank Applictaion");
			System.out.println("-----------------------------");
			System.out.println("                              ");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit Application");
			int option = scanner.nextInt();

			switch (option) {
			case 1: //take customer details dynamically
				try {
					  String userName=scanner.nextLine();
		                boolean nameValid=false;
		                System.out.println("Enter Your Name");
		                do{
		                    userName=scanner.nextLine();
		                    nameValid= bank.nameValidation(userName);
		                    if(!nameValid)
		                    {
		                        System.out.println("Please enter Alphabets only");
		                        System.out.println("Enter Your Name");                       
		                    }
		                }while(!nameValid);

		                long mob=0;
		                boolean isMobOk=false;
		                System.out.println("Enter contact number :");
		                do{
		           
		                	mob  = scanner.nextLong();
		                isMobOk=bank.mobNotValid(mob);
		                if(!isMobOk)
		                {
		                    System.out.println("Enter valid Contact Number ");
		                    System.out.println("Enter your Contact Number :");
		                }}while(!isMobOk);
					System.out.println("Enter Your Branch : ");
					String branch = scanner.next();

				
					boolean acTypeValid = false;
					System.out.println("Enter Your Account Type : ");
					String acType;
					do{
						 acType = scanner.next();
					acTypeValid=bank.accountTypeValidation(acType);
					if(!acTypeValid){
						System.out.println("Enter valid Account type savings/current");
					}
					}while(!acTypeValid);
				
					
					
					System.out.println("Enter Your Account Balance : ");

					Long balance = scanner.nextLong();

					Long acno = mob + 5000;

					AccountDet account = new AccountDet();// complete Account info
					account.setAcno(acno);
					account.setName(userName);
					account.setPhoneNo(mob);
					account.setBranch(branch);
					account.setAcType(acType);
					account.setBalance(balance);

					System.out.println("Inserting Account Details in Map Please Wait....");

					long accNum = bank.insertAccount(account);

					System.out.println("---------Account Created Successfully-------");
					System.out.println("Your Account Number is :" + accNum);
					System.out.println("============================================");
				} catch (AccountNotFound e) {
					System.out.println("Enter valid Details");
				}

				break;

			case 2://Shows the available balance
				try{
			
				
					System.out.println("Enter Account number :");
					Long bnk = scanner.nextLong();
					AccountDet bnks = bank.retrieveAccount(bnk);
					System.out.println("Your Balance is :" + bnks.getBalance());
					System.out.println("============================================");
				
			}catch(AccountNotFound e)
			{
				System.out.println(e.getMessage());
			}
			
				break;

			case 3:// take amount to be deposited and updates the balance
				try{
				System.out.println("Enter your account number :");
				Long accno2 = scanner.nextLong();
				System.out.println("Enter the Amount to be deposited");
				Long depositAmt = scanner.nextLong();
				AccountDet b3 = bank.depositMoney(accno2, depositAmt);
				System.out.println("Updated Balance= " + b3.getBalance());
				System.out.println(b3);
				System.out.println("--------AMOUNT DEPOSITED SUCCESSFULLY---------");
				System.out.println("============================================");
				}catch(AccountNotFound ae){
					System.out.println(ae.getMessage());
				}
				break;

			case 4:// take amount to be withdrawn and updates the balance
				try{
				System.out.println("Enter your account number :");
				Long accno3 = scanner.nextLong();
				System.out.println("Enter the amount to be withdrawn");
				Long withdrawAmt = scanner.nextLong();
				AccountDet b4 = bank.withdrawMoney(accno3, withdrawAmt);
				System.out.println("Remaining balance :" + b4.getBalance());
				System.out.println("----------AMOUNT WITHDRAWN SUCCESSFULLY---------");
				System.out.println("============================================");
				}catch(AccountNotFound ae){
					System.out.println(ae.getMessage());
				}
				break;

			case 5:// fund transfer btw 2 accounts
				try{
				System.out.println("Enter the Sender account number :");
				Long sender = scanner.nextLong();
				System.out.println("Enter the Receiver account number :");
				Long receiver = scanner.nextLong();
				System.out.println("Enter the Amount to be transfered :");
				Long amt = scanner.nextLong();
				bank.transfer(sender, receiver, amt);
				
				System.out.println("============================================");
				}catch(AccountNotFound ae){
					System.out.println(ae.getMessage());
				}
				break;

			case 6:// to print all the transactions
				System.out.println("Your Transactions : ");
				List<Transaction> result = bank.printTransaction();
				Iterator<Transaction> itr = result.iterator();
				while (itr.hasNext()) {
					System.out.println(
							"=======================================================================================================");
					System.out.println(
							"Tran  Id      Tran Type      New Balance     Old Balance          From Account          To Account    ");
					System.out.println(
							"=======================================================================================================");
					while (itr.hasNext()) {
						Transaction tran = itr.next();
						System.out.println(tran.getTransid() + "           " + tran.getTransType() + "           "
								+ tran.getNewBal() + "            " + tran.getOldBal() + "             "
								+ tran.getFrmAc() + "            " + tran.getToAc() + "               ");
						// System.out.println(itr.next());
					}
				}
				break;

			case 7:
				System.out.println("Thank You");
				System.exit(0);
				scanner.close();
			}

		}
	}
}
