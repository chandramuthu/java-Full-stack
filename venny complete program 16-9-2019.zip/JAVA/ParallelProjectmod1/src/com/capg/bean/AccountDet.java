package com.capg.bean;

public class AccountDet {
	private Long acno;
	private String name;
	private Long phoneNo;
	private String branch;
	private String acType;
	private Long balance;

	public Long getAcno() {
		return acno;
	}

	public void setAcno(Long acno) {
		this.acno = acno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAcType() {
		return acType;
	}

	public void setAcType(String acType) {
		this.acType = acType;
	}

	@Override
	public String toString() {
		return "AccountDet [acno=" + acno + ", name=" + name + ", phoneNo=" + phoneNo + ", branch=" + branch
				+ ", acType=" + acType + ", balance=" + balance + "]";
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

}
