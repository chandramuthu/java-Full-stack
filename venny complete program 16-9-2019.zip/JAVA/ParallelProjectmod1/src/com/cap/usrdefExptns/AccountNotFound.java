package com.cap.usrdefExptns;


	@SuppressWarnings("serial")
	public class AccountNotFound extends RuntimeException {
		public AccountNotFound(String errMsg) {
			super(errMsg);
		}
		
	}


