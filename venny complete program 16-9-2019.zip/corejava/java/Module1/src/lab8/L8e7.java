package lab8;

public class L8e7 {

}
