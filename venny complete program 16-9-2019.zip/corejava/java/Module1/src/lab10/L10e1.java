package lab10;

public class L10e1 {

}
