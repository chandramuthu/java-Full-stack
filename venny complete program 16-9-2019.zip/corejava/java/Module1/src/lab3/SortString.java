package lab3;

import java.util.Arrays;
import java.util.Scanner;



public class SortString {
	
	String[] sortString(String[] a)
	{
	    
	    String[] str=new String[a.length];
	    Arrays.sort(a);
	    
	    int l=a.length;
	    int div=l/2;
	    if(l%2==0)
	    {
	        for(int i=0;i<l;i++)
	        {
	            
	            if(i<div)
	            {
	                str[i]=a[i].toUpperCase();
	            }
	            else
	            {
	                str[i]=a[i].toLowerCase();
	            }
	        }
	    }    
	    else
	    {
	        for(int i=0;i<l;i++)
	        {
	            
	            if(i<div+1)
	            {
	                str[i]=a[i].toUpperCase();
	            }
	            else
	            {
	                str[i]=a[i].toLowerCase();
	            }
	        }
	        
	    }
	    
	    
	    return str;
	}


	public static void main(String[] args) {
	    SortString s=new SortString();
	    
	     System.out.println("Enter a number :");
	    
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();  
	    
	    System.out.println("Enter the strings :"); 
	    String a[]=new String[n];
	    
	    for(int i=0;i<n;i++)
	    {
	        a[i]=sc.next();
	        
	    }  
	    String[] c=s.sortString(a);
	    for(int i=0;i<c.length;i++)
	    {
	        System.out.println(c[i]);
	    }
	    sc.close();
	}
	}
	 





