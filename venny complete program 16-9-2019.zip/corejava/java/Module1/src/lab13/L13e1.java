package lab13;




import java.util.Scanner;



@FunctionalInterface
interface pow1
{
    public void power1(int a,int b);
}
public class L13e1
{
    public static void main(String[] args) 
    {
        @SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number");
        int x=sc.nextInt();
        System.out.println("Enter second number");
        int y=sc.nextInt();
        
        pow1 expo=(a,b)-> System.out.println(Math.pow(x, y));//use the same variable used in the interface method
        expo.power1(x, y);
    }
}
 