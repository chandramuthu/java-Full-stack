package lab1;

import java.util.Scanner;



public class SumOfSquares {
	static int sum,n,i;
	static int calculateDifference(int n) //Calculate the difference
	{
		int a=0;
		
		for(i=0;i<n;i++)
		{
			int sos=(n*(n+1)*(2*n+1))/6;  //Sum of Square
			a=sos;
		}
		int b=(n*(n+1))/2;                //Sum of nos and their squares
		int c=b*b;						  //Square of sum
		sum=c-a;
		return sum;
	}
	
public static void main(String[] args) {
	System.out.println("Enter a number : ");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	System.out.println(SumOfSquares.calculateDifference(n));
	sc.close();
}
}
