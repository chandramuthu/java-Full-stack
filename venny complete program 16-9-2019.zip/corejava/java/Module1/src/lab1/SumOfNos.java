package lab1;

import java.util.Scanner;

public class SumOfNos {
	 static int n,sum;
     static int calculateSum(int n)   //calculate Sum
      {
         if(n%3==0 || n%5==0)
         {
             int sum= (n*(n+1))/2;
             return sum;
         }
         else
         {
             System.out.println("This number is not divisible by 3 or 5");
             return sum;
         }
      
      }    
  public static void main(String args[])
  {
      
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter any number:");
      int n=sc.nextInt();
      System.out.println(SumOfNos.calculateSum(n));
      sc.close();
  }
}
