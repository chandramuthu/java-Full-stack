package lab5;

import java.util.Scanner;

public class TrafficLight {
	public static void main(String[] args) {
		String color;

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the colour:");
		color = sc.next();
		switch (color) {
		case "Red":
		case "red":
			System.out.println("Stop");
			break;
		case "Yellow":
		case "yellow":
			System.out.println("Ready");
			break;
		case "Green":
		case "green":
			System.out.println("Go");
			break;
		default:
			System.out.println("There is no related choice found");
			sc.close();
		}
	}
}
