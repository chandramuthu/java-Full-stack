package lab5;

import java.util.Scanner;

public class EmpExptn {
	 public static void main(String[] args) 
     {
           @SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
           System.out.println("Enter employee salary:");
           int salary=sc.nextInt();
           try 
           {
               if(salary<3000)
               {
                   throw new Exception("Salary should be above or equal to 3000");
               }
           } 
           catch(Exception e)
           {
                   System.err.println(e.getMessage());
                   
           }
       }
	 
}


