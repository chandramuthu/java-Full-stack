package com.capg;

public class Add {
 public int sum (int a, int b){
	 System.out.println("sum of  " +a +b);
	return(a+b);
 }
}
