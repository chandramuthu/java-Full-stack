package com.capg;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

 

public class Test1 {
    @Before
    public void m1()
    {
        System.out.println("Executes after each @test case");
    }
    @BeforeClass
    public static void m2()
    {
        System.out.println("Executes omly one time and first");
    }
    @Test
    public void m3()
    {
        System.out.println("Test case1");
    }
    @After
    public void m4()
    {
        System.out.println("Executes after each @test case");
    }
    @AfterClass
    public static void m5()
    {
        System.out.println("Executes omly one time and first");
    }
    @Test
    public void m6()
    {
        System.out.println("Test case2");
    }
    @Ignore
    public void m7()
    {
        System.out.println("It will ignored by junit compiler");
    }
}