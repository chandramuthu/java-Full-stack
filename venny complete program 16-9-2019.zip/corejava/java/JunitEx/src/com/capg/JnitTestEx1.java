package com.capg;

import static org.junit.Assert.*;

import org.junit.Test;

public class JnitTestEx1 {

	Add t = new Add();
	int i = t.sum(100, 20);
	int j = 120;

	@Test
	public void test() {
		System.out.println("Sum is : " + i + " = " + j);
		assertEquals(i, j);
	}

}
