package com.cap.dao;

import java.util.HashMap;
import java.util.Map;

import com.cap.bean.Employee;

public class EmpDaoImpl implements EmpDaoIntrface {

	Map<Integer,Employee> employees=new HashMap<Integer,Employee>();

	@Override
	public Employee insertEmployee(Employee employee) {
	return employees.put(employee.getEmpId(), employee);
	
	}

	@Override
	public Employee retrieveEmployee(Integer eid) {
		// TODO Auto-generated method stub
		return employees.get(eid);
	}
	
	
	
	

}
