package com.cap.ui;

import java.util.Scanner;

import com.cap.bean.Employee;
import com.cap.service.EmpServiceImpl;
import com.cap.service.EmpServiceIntrface;
 

public class MainEmpUI {
    static EmpServiceIntrface service = new EmpServiceImpl();

 

    static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {

 

        while(true)
        {
            System.out.println("Welcome to Employee Apllictaion");
            System.out.println("1.create Employee");
            System.out.println("2.Select employee");
            System.out.println("3.exit");
            int option= scanner.nextInt();
            
            switch(option){
            case 1:
                System.out.println("Enter Your Id: ");
                int empId = scanner.nextInt();
                System.out.println("Enter Your Name: ");
                String empName = scanner.next();
                System.out.println("Enter Your salary ");
                int empSal = scanner.nextInt();

 

                Employee employee = new Employee();//complete emp info
                employee.setEmpId(empId);
                employee.setEmpName(empName);
                employee.setEmpSal(empSal);
                System.out.println("Inserting Employee in Map");
        
                service.insertEmployee(employee);
        
                System.out.println("************");
                System.out.println("Inserting employee********");
                System.out.println("*************");
                break;
        case 2:
            System.out.println("Fetching Employee ");
            System.out.println("Enter your Id ");
            int empId1 =scanner.nextInt();
            Employee emp1=service.retrieveEmployee(empId1);
            System.out.println(emp1);
            System.out.println("**************");
            break;
        case 3:
            System.out.println("Thank You");
            System.exit(0);
        scanner.close();
    }
}
}
}