package com.cap.dao;

import com.cap.bean.Employee;

public interface EmpDaoIntrface {

Employee insertEmployee(Employee employee);
Employee retrieveEmployee(Integer eid);
}
