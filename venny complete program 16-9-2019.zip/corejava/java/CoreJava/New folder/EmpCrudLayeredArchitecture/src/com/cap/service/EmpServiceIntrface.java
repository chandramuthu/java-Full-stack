package com.cap.service;

import com.cap.bean.Employee;

public interface EmpServiceIntrface {
Employee insertEmployee(Employee employee);
Employee retrieveEmployee(Integer eid);
}
