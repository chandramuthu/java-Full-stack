package com.cap.service;

import com.cap.bean.Employee;
import com.cap.dao.EmpDaoImpl;
import com.cap.dao.EmpDaoIntrface;

public class EmpServiceImpl implements EmpServiceIntrface
{
	EmpDaoIntrface dao=new  EmpDaoImpl(); 
	
	@Override
	public Employee insertEmployee(Employee employee) 
	{
		return dao.insertEmployee(employee);
	}

	@Override
	public Employee retrieveEmployee(Integer eid) 
	{
		return dao.retrieveEmployee(eid);
	}
}
