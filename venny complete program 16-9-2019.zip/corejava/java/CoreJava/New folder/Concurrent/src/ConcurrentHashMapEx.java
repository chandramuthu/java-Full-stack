import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapEx {
public static void main(String[] args) {
	ConcurrentHashMap<Integer, String> cm=new ConcurrentHashMap<Integer, String>();
	cm.put(10, "nandy");
	cm.put(20, "sam");
	cm.put(30, "pooja");
	System.out.println(cm);
	cm.putIfAbsent(20,"m" );
	/*System.out.println(cm);
	cm.remove(30,"ven");
	cm.replace(10, "meg", "venny");
	System.out.println(cm);
*/}
}
