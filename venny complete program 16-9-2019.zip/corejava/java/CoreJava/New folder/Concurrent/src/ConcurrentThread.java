import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentThread extends Thread{

	static ConcurrentHashMap<Integer, String> chm=new ConcurrentHashMap<Integer, String>();
	
	public void run()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println("Child Thread got chance");
		chm.put(40, "Welcome");
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		chm.put(10, "Welcome");
		chm.put(20, "To");
		chm.put(30, "Capgemini");
		
		ConcurrentThread ct=new ConcurrentThread();
		ct.start();
		Set<Integer> s=chm.keySet();
		Iterator<Integer> itr=s.iterator();
		while(itr.hasNext())
		{
			Integer i=(Integer) itr.next();
			System.out.println("Main Thread Iterating");
			System.out.println("Current Key is "+i+"and value is:"+chm.get(i));
			Thread.sleep(1000);
			System.out.println(chm);
		}
		
		 
	}
}
