import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadPoolEx3 {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException
	
	{
		//for Scheduling tasks
		ExecutorService service=Executors.newFixedThreadPool(10);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		List<Future> allFutures = new ArrayList();
		//Storing values in ArrayList
		for(int i=0; i<100;i++){
			@SuppressWarnings("rawtypes")
			Future future=service.submit(new Tasknew());
			allFutures.add(future);
			
		}
		//iterating array list
		for (int i =0; i<100; i++){
			@SuppressWarnings("unchecked")
			Future<Integer> future=allFutures.get(i);
			Integer result=future.get();
		System.out.println(result);
		}
	}
}
class Tasknew implements Callable<Integer>{
	public Integer call()throws Exception{
		Thread.sleep(2000);
		return new Random().nextInt();
	}
}