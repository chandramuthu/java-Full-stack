class VariableEx
{
 static int x=20;
 static int y=10;
	 static void addTwo()
	 {
		int a=123;
		int b=345;
		int c=a+b;
		System.out.println("Sum of two nos"+c);
		System.out.println("Sum of 2 nos"+(x+y));
	 }
	 static void subTwo()
	 {
		int a=345;
		int b=123;
		int c=a-b;
		System.out.println("Diff of two nos"+c);
		System.out.println("Diff of 2 nos"+(x+y));
	 }
	static int sub1(int a, int b)
	{
		return a-b;
	}
public static void main(String args[])
{
  VariableEx.addTwo();
  int sub= VariableEx.sub1(90,50);
  int val=sub+100;
System.out.println(sub);
System.out.println(val);
  VariableEx.subTwo();
  
  System.out.println("Welcome");
}
}
  