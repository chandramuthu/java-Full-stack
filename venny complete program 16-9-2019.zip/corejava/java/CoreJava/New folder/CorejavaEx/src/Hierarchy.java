
class Animal
	{  
		void pet()
		{
			System.out.println("Domestic Animals");
		}  
    }  

	class Dog extends Animal
	{  
		void breed()
		{
			System.out.println("gsd");
		}  
    }  

	class Cat extends Animal
	{  
		void color()
		{
			System.out.println("ginger");
		}  
    }  

	class Hierarchy
	{  
			public static void main(String args[]){  
			Cat c=new Cat();  
			c.color();  
			c.pet();  
    }
}  
