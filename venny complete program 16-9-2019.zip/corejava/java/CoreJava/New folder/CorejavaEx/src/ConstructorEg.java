
public class ConstructorEg {
	public ConstructorEg(){
		System.out.println("Default Constructor");
}
	public ConstructorEg(String name) {
		System.out.println("String Param Constructor");
	}
	public ConstructorEg(int a,int b){
		System.out.println("Int param Constructor");
	}
void m1()
{
	System.out.println("method");
}
public static void main(String[] args) {
	ConstructorEg t=new ConstructorEg("hgdfb");
	ConstructorEg t1=new ConstructorEg("10,20");
	ConstructorEg t2=new ConstructorEg();
	t.m1();
	t1.m1();
	t2.m1();
}
}
