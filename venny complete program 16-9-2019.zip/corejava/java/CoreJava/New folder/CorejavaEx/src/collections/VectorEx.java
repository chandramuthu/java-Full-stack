package collections;

import java.util.Enumeration;
import java.util.Vector;

public class VectorEx {
	public static void main(String[] args) {
		Vector<String> DaysOfWeek = new Vector<String>();
		 DaysOfWeek.add("Sun");
		 DaysOfWeek.add("Mon");
		 DaysOfWeek.add("Tue");
		 DaysOfWeek.add("Wed");
		 DaysOfWeek.add("Thu");
		 DaysOfWeek.add("Fri");
		 DaysOfWeek.add("Sat");
		 
		 System.out.println(DaysOfWeek);
		 
		 Enumeration<String> days= DaysOfWeek.elements();
		 
		 while(days.hasMoreElements()); //hasNext();
		 {
			 System.out.println(days.nextElement());
		 }
		 
	}
}
