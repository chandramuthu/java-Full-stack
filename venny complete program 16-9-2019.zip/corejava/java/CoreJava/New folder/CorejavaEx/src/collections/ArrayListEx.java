package collections;

import java.io.Serializable;
import java.util.Vector;

public class ArrayListEx 
{
	public static void main(String[] args) 
	{
		//ArrayList al=new ArrayList();//default size 10 if it exceeds it increases to ==> 16 then ==> 25 ...    
		//LinkedList al=new LinkedList();
		Vector<Comparable> al=new Vector();
		
		al.add('@');//character
		al.add("VEN");//string
		al.add(true);//boolean
		al.add(12.2f);//float   any type of data can be inserted
		System.out.println(al);
		
		Vector<Serializable> al1=new Vector();
		al1.add(13678);
		al1.add('*');
		al1.add("hello");
		al1.add('*');
		al1.add("WORLD");
		al1.add(15.98f);//float   any type of data can be inserted
		System.out.println(al);
		al1.add(al);
		System.out.println(al1);
		al.capacity();
		System.out.println(al);
		al1.hashCode();
		System.out.println(al1);
		al1.elementAt(3);
		System.out.println(al1.elementAt(6));
	}
}
                                                                                                                                                                              