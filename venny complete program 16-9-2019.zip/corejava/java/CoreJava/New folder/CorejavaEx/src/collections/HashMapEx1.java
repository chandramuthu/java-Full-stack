package collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEx1 
{
	public static void main(String[] args) 
	{
		LinkedHashMap<Integer,String> lm=new LinkedHashMap<Integer,String>();
		
		lm.put(1273, "Ven");
		lm.put(2034, "Meg");
		lm.put(548, "ved");
		lm.put(0736, "kee");
		lm.put(9687, "Avi");
		System.out.println(lm);
		
		Set<?> set=lm.entrySet();
		
		Iterator<?> itr=set.iterator();
		while(itr.hasNext()){
			Entry<?, ?> entry = (Entry<?, ?>) itr.next();
			System.out.println(entry.getValue());
			System.out.println(itr.next());
		}
		
		
	}
}
