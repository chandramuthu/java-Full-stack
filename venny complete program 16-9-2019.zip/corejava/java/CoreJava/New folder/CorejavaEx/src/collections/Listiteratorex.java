package collections;

 

	import java.util.ArrayList;
	import java.util.ListIterator;

	 

	public class Listiteratorex {
	    public static void main(String[] args) {
	        ArrayList<String> t=new ArrayList<String>();
	            t.add("ab");
	            t.add("bc");
	            t.add("cd");
	            t.add("ef");
	            
	            System.out.println(t);
	            ListIterator<String> itr1=t.listIterator();
	            while(itr1.hasNext())
	            {
	System.out.println(itr1.next()+" ");
	            }
	            while(itr1.hasPrevious())
	                {
	            String name=(String) itr1.previous();
	                    if(name.equals("cd")){
	                    itr1.set("Ven");
	                    System.out.println(itr1.next());
	                    itr1.previous();
	                    
	                    }
	                    else
	                    {
	                    System.out.println(name);
	                    }
	                    
	        }}
	}
