package collections;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetDemo {
 public static void main(String[] args) {
	TreeSet<Integer> ts=new TreeSet<Integer> (new MyComparator1());
	ts.add(10);
	ts.add(20);
	ts.add(30);
	System.out.println("set:" +ts);
}
}

class MyComparator1 implements Comparator<Object>
{
	public int compare(Object o1,Object o2) 
	{
		Integer i1=(Integer) o1;
		Integer i2=(Integer) o2;
	
		
		return i1.compareTo(i2);
	
		
		
		//	return i2.compareTo(i1);
	
		
		
		/* if(i1<i2)
			return +1;
		else if(i1>i2)
			return -1;
		else
			return 0;
			}*/
	
}
}
