package collections;

public class CompareToEx {
	public static void main(String[] args) {
		System.out.println("A".compareTo("Z"));
		System.out.println("Z".compareTo("K"));
		System.out.println("A".compareTo("A"));
		System.out.println("A".compareTo("null"));
	}
}
