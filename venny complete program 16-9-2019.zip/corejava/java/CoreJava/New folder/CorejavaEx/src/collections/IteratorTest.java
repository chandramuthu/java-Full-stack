package collections;

import java.util.ArrayList;
import java.util.Iterator;


public class IteratorTest {
	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("ven");
		al.add("meg");
		al.add("kee");
		al.add("ved");
		al.add("kee");
		al.add("ven");
		System.out.println(al);
		
		Iterator<String> itr1= al.iterator();
		
		while(itr1.hasNext())
		{
			String name=(String) itr1.next();//ven
			if(name.equals("kee"))
			{
				itr1.remove();
			}
			else
			{
			  System.out.println(name);
		    }
	}
}
}