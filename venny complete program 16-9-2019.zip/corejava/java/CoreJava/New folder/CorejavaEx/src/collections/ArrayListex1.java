package collections;



import java.util.ArrayList;



public class ArrayListex1 {
    int emp_id;
    String ename;
    int salary;
    
    
    public ArrayListex1(int emp_id, String ename, int salary) {
        super();
        this.emp_id = emp_id;
        this.ename = ename;
        this.salary = salary;
    }
    
    public String toString() {
        return "ArrayListex1 [emp_id=" + emp_id + ", salary=" + salary + ", ename=" + ename + "]";
    }

 

     
public static void main(String[] args) {
    ArrayListex1 e1=new ArrayListex1(123,"rajesh", 10000);
        ArrayListex1 e2=new ArrayListex1(122,"sajesh", 20000);
        ArrayListex1 e3=new ArrayListex1(125,"pajesh", 30000);
        ArrayListex1 e4=new ArrayListex1(124,"kajesh", 40000);

 

    ArrayList al=new ArrayList();
    al.add(e1);
    al.add(e2);
    al.add(e3);
    al.add(e4);
    System.out.println(al);
    
}
}
 