package multiThreading;

class First{
    public synchronized void display(String msg)
    {
        System.out.print("[" + msg);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("]");
    }
}
class Second extends Thread{
    String msg;
    First fobj;
   
    Second(First fobj,String msg)
    {
        this.fobj=fobj;
        this.msg=msg;
        this.start();
    }
    public void run(){
        fobj.display(msg);
    }
}
public class Synchronizationex {
    public static void main(String[] args) {
        First fnew=new First();
        Second ss=new Second(fnew,"welcome");
        Second ss1=new Second(fnew,"new");
        Second ss2=new Second(fnew,"java programmer");
        }
}