/*package multiThreading;

import java.awt.List;

public class Removez
{
	public static void main(String[] args) 
	{
		
		int i;
		String str=new String();		
		for(i=0;i<str.length();i++)
		{
			if(str.contains("z"))
			{
				for(j=i;j<str.length;j++)
					j=str(j+1);
				    str(j+1)="";
				
			}
		}
			
	}
}

*/