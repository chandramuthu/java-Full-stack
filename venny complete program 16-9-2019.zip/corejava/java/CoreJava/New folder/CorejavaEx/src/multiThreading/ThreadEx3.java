package multiThreading;


class Test2 extends Thread
{

	@Override
	public void run() 
	{
		Thread.currentThread().setName("ven");
		//Thread.currentThread().setPriority(10);
		for(int i=0;i<5;i++)
		{
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread());
			System.out.println("Child Class");
		}
		
	}
	
}
public class ThreadEx3 
{
	public static void main(String[] args) //5
	{
		Thread.currentThread().setPriority(8);
		Test2 t =new Test2();
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println(Thread.currentThread());
			System.out.println(Thread.currentThread().getPriority());
			System.out.println("Parent Class");
			
			
		}
		
	}
}
