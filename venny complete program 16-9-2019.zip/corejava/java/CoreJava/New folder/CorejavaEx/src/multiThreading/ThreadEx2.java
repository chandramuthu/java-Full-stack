package multiThreading;
class Test1 extends Thread
{

	@Override
	public void run() 
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Class");
		}
		
	}
	
}
public class ThreadEx2 
{
	public static void main(String[] args) 
	{
		Test1 t =new Test1();
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("Parent Class");
		}
		
	}
}
