package multiThreading;

public class InterThreadCommunication {

}
