package multiThreading;

class Account{
	public int balance;//5000
	  
	public Account() {
		balance= 5000;
		
	}
	
	public void withdraw(int bal) throws InterruptedException
	{
		Thread.sleep(1000);
		
		balance=balance-bal;
		System.out.println("Amount withdrawn =" +bal);
		System.out.println("Remaining Balance ="+balance);
	}

public void deposit(int bal)
{
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	balance=balance+bal;
	System.out.println("Amount deposited =" +bal);
	System.out.println("Remaining Balance ="+bal);
}

public void enquiry() throws InterruptedException 
{
	Thread.sleep(3000);
	System.out.println("Availabe Balance" +balance);
	
}
}

class Transaction implements Runnable{
	Account obj;
	
    Transaction(Account a)
    {
    	obj=a;
    }
	@Override
	public void run() {
		try {
			obj.withdraw(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		obj.deposit(500);
		try {
			obj.enquiry();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

public class ThreadSync
{
	public static void main(String[] args) throws Exception
	{
		Account a=new Account();
		Transaction w1=new Transaction(a);
		Thread t1=new Thread();
		Thread t2=new Thread();
		t1.start();
		t2.start();
	}
}
