package stringTask;

public class Pgm2 {
	public static void main(String[] args) 
	{
		String a="harry potter";
		String s1= a.substring(0,1).toUpperCase()+a.substring(1).toLowerCase();
		System.out.println(s1);
	}
}
