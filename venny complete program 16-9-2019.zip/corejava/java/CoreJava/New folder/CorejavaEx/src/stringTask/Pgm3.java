package stringTask;

public class Pgm3
{
	
		public static void main(String[] args)
		{
			String s1 ="Capgemini";
			
			String s2 ="Capgemini";
			System.out.println(s1.matches(s2));
         }
 }

