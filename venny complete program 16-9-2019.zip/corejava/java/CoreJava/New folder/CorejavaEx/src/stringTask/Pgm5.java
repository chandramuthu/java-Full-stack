package stringTask;

import java.util.Scanner;

public class Pgm5 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any sentence: ");
		String a=sc.nextLine();
		if(a==null || a.isEmpty())
		{
			System.out.println("Please enter a sentence");
		}
		else
		{
			String sen[]= a.split(" ");          
			System.out.println("The numbers of words present in this sentence is: "+ sen.length);
			sc.close();
		}
	}
}
