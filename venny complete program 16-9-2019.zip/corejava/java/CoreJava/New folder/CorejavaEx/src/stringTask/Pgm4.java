package stringTask;

public class Pgm4 
{
	 public static void main(String[] args) 
	 {
	        String s1="Vennela";
	        String s2="Rao";
	        System.out.println(s1.endsWith(s2));
	 }

}
