package streamEx;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LamdaWithCollectionAndStreams {
	public static void main(String[] args) {
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(15);
		al.add(5);
		System.out.println(al);
		
		List<Integer> l=al.stream().filter(i -> i%2 == 0).collect(Collectors.toList());
		System.out.println("Filter to print Even Values :" +l);
		
		System.out.println("Map to print double value");
		List<Integer> l1=al.stream().map(i -> i * 2).collect(Collectors.toList());
		System.out.println("Map to print Double value :" +l1);
		
		long cn = al.stream().count();
		System.out.println("Count of no of elements :" +cn);
		

	    List<Integer> l2 = al.stream().sorted((i1,i2)-> (i1<i2) ? 1: (i1>i2) ? -1:0).collect(Collectors.toList());
	    System.out.println("Displayed in descending order "+l2);
	    
	    Integer minVal= al.stream().min((i1,i2)-> -i1.compareTo(i2)).get();   	    
	    System.out.println("Minimum value is.... "+ minVal);
	  
	    Integer maxVal=al.stream().max((i1,i2)-> i2.compareTo(i1)).get();
	    System.out.println("Maximum value is.... "+ maxVal);

		
		//printing using 
	    al.stream().forEach(i -> {
	    	System.out.println("The elemnts are : " +i);
	    });
	}
}
