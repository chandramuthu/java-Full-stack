package javaEg;

public class ExptnHandling {
public static void main(String args[]) {
	try{
		int a[]=new int[5]; //0...4
		a[4]=20/0;
		String s="1bhjnk";
		int x=Integer.parseInt(s);
		System.out.println(s.length());	
		System.out.println("no error"+a[4]+x);
		}
	catch(ArrayIndexOutOfBoundsException ae) //jvm
	{
	System.out.println("Please enter valid index");
	}
	catch(ArithmeticException ae)
	{
		System.out.println("Dont Enter 0 as denominator");
	}
	catch(NumberFormatException e)
	{
		System.out.println("We cant convert string to number");
	}
	catch(Exception e) //parent class for all exceptions
	{
		System.out.println("Unable to find length of String"+e);
	//e.printStackTrace
	//System.out.println(e.getMessage());
	}
	finally{
		System.out.println("Executes every time for closing connections..");
	}
	System.out.println("remaining code execution....");
}
}
