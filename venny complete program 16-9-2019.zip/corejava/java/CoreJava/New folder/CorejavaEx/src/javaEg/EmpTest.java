/*package javaEg;

public class EmpTest {
	public static void main(String[] args) {
		Emp e=new Emp();
		e.setEmpid(123);
		e.setEmpname("ven");
		e.setEmpsal(20000);
		e.setAtmpin(4567);
		
		System.out.println(e.getEmpid());
		System.out.println(e.getEmpname());
		System.out.println(e.getEmpsal());
	
	}
}
*/