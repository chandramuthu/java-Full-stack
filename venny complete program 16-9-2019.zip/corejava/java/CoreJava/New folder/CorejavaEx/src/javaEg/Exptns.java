/*package javaEg;

//parameterized constructor
 public class Exptns extends Exception
{
	 public Exptns(String errorMsg)
	 {
		 super (errorMsg);
	 }
}
 public class Exptns1
 {
	 static void validation(int age1) throws Exptns
	 {
		 if(age1<18)
			 
			 throw new Exptns("you are not eligible to vote");
			 else
				 System.out.println("you are eligible to vote");
	 }
	 
public static void main(String args[]) throws Exptns
{
	Exptns1.validation(16);
}
 }
*/