package javaEg;

public class ExpnNestedTry {
public static void main(String[] args) {
	try{
	int c=12/4;
	try{
		System.out.println("divison");
		int b=30/0;		
	} catch (ArithmeticException e) {
		// TODO: handle exception
		System.out.println(e);
	}
	try {
		int a[]=new int[3];
		a[3]=4;
	} catch (ArrayIndexOutOfBoundsException e) {
		// TODO: handle exception
		System.out.println(e);
	}finally
	{
		System.out.println("always will get excuted");
	}
	System.out.println("Remaining try Statements");
}
 catch (Exception e){
	 System.out.println("Handled");
 }
 System.out.println("Normal Execution");
}
}