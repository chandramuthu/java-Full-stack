/*package javaEg;

public class Emp {
	private int empid;
	private String empname;
	private int empsal;
	private int atmpin;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	public void getEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpsal() {
		return empsal;
	}
	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}
	
	public void setAtmpin(int atmpin) {
		this.atmpin = atmpin;
	}
	sc.close();
	
}
*/