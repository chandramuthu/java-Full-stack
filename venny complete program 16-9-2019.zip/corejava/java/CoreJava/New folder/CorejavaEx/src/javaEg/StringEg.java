/*p+ackage javaEg;

public class StringEg {
	public static void main(String[] args) {
		String s1 ="capgemini";
		
		String s2 ="Capgemini";
		
		String s3=new String("capgemini");
		
        String s4="hello";
		
		String s5="Hallo";
		
		String s6="world";
		
		String s7=" Wecome to Capgemini";
		
		System.out.println(s1.matches(s3));
		
		System.out.println(s1.equals(s3));//true
		System.out.println(s1==s3);//false
		System.out.println(s1.compareToIgnoreCase(s2));//true
		System.out.println(s1==s2);//false		ss
		System.out.println(s4.compareTo(s5));//32 compares unicode value of each charecter
		System.out.println(s4.replace(s2, s5));//helo replaces old value with new one
		System.out.println(s2.charAt(3));//returns char value at specified index
		System.out.println(s4.concat(s6));
		System.out.println(s1.contains(s5));
		System.out.println(s1.codePointAt(2));
		System.out.println(s1.contentEquals(s3));
		System.out.println(s2.hashCode());
		System.out.println(s1.matches(s3));
		System.out.println(s5.isEmpty());	
		System.out.println(s1.endsWith(s3));
		System.out.println(s3.length());		
		System.out.println(s4.codePointBefore(2));		
		System.out.println(s1.startsWith(s2));
		System.out.println(s4.toUpperCase());
		System.out.println(s5.toLowerCase());		
		System.out.println(s1.toCharArray());		
		System.out.println(s7.trim());//eliminates white spaces
		System.out.println(s3.length());
		System.out.println(s1.equals(s3));//true
		System.out.println(s1==s3);//false
		System.out.println(s1.compareToIgnoreCase(s2));//true
		System.out.println(s1==s2);//false		
		System.out.println(s4.compareTo(s5));//32 compares unicode value of each charecter
		System.out.println(s4.replace(s2, s5));//helo replaces old value with new one
		System.out.println(s2.charAt(3));//returns char value at specified index
		System.out.println(s4.concat(s6));
		System.out.println(s1.contains(s5));
		System.out.println(s1.codePointAt(2));
		System.out.println(s1.contentEquals(s3));
		System.out.println(s2.hashCode());
		System.out.println(s1.matches(s3));
		System.out.println(s5.isEmpty());	
		System.out.println(s1.endsWith(s3));
		System.out.println(s3.length());		
		System.out.println(s4.codePointBefore(2));		
		System.out.println(s1.startsWith(s2));
		System.out.println(s4.toUpperCase());
		System.out.println(s5.toLowerCase());		
		System.out.println(s1.toCharArray());		
		System.out.println(s7.trim());//eliminates white spaces
		System.out.println(s3.length());
		
	
		
		
	}
}
*/