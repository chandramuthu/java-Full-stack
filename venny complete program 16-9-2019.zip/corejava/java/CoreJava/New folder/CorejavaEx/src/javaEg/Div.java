package javaEg;

import java.util.Scanner;

public class Div {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	System.out.println("Enter 1st no :");
	int fnum=sc.nextInt();
	System.out.println("Enter 2nd no :");
	int snum=sc.nextInt();
	try{
	int division=fnum/snum;
	System.out.println("Solution" +division);
	sc.close();
	}catch(ArithmeticException ae )
	{
		System.out.println("Dont enter 0 as denominator");
		
	}
	System.out.println("remaining lines of code.....");
	}
}
