package javaEg;
import com.cap.Test;
public class Test1 extends Test {
	public static void main(String[] args) {
		Test t=new Test();
		System.out.println(t.eid);
				
	}
}
