/*package javaEg;

public class Emp1 {
	public class Emp {
		private int empid;
		private String empname;
		private int empsal;
		
		
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		
		public void getEmpid(int empid) {
			this.empid = empid;
		}
		public String getEmpname() {
			return empname;
		}
		public void setEmpname(String empname) {
			this.empname = empname;
		}
		public int getEmpsal() {
			return empsal;
		}
		public void setEmpsal(int empsal) {
			this.empsal = empsal;
		}			
	}
	
public static void main(String[] args) {
	Emp1 employee= new Emp1();
	employee.setempid(11011);
	employee.setempname("Ven");
	employee.setempsal("100000");
}
}
*/