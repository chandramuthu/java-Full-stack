import java.util.Scanner;

public class Emp{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter emp id ");
		int id =sc.nextInt();
		System.out.println("Enter emp Name ");
		String Name=sc.next();
		System.out.println("Enter Employee Address ");
		String Address=sc.next();
		Name+=sc.nextLine();  
		System.out.println("Emp ID  "+id);
		System.out.println("Emp Name  " +Name);
		System.out.println("Address " +Address);
		sc.close();
	}	
}
