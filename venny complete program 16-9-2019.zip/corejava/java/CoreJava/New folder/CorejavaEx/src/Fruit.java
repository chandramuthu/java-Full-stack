class Fruit{

public static void main(String args[])
{  
	greens d=new greens();  
	d.mango();
	d.carrot();
	d.mint();  
}

		void mango()
		{
			System.out.println("Yellow");
		}  
	}  

	class veg extends Fruit
	{  
		void carrot()
		{
			System.out.println("Orange");
		}  
	}  
	
	class greens extends veg
	{  
		void mint()
		{
			System.out.println("Green");
		}  
	 
		
		
	}