
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

 

class Employee12 
{
    String name;
    String add;
    int sal;
    public Employee12(String name, String add, int sal) {
        super();
        this.name = name;
        this.add = add;
        this.sal = sal;
    }
	@Override
	public String toString() {
		return "name=" + name + ", add=" + add + ", sal=" + sal+"\n";
	}
   
    
     }

 

public class Hashmaptask {
public static void main(String[] args) {
	System.out.println("Enter the Mobile No.");
	Scanner sc=new Scanner(System.in);
	long num;
	num=sc.nextLong();
    HashMap<Long, Employee12> m=new HashMap<Long, Employee12>();
    
    Employee12 e1=new Employee12("ven","Bangalore",20000);
    Employee12 e2=new Employee12("Meg","Madurai",65585);
    Employee12 e3=new Employee12("kee","Vijaynagar",2545411);
    Employee12 e4=new Employee12("Navu","rajajinagar",545452 );
    Employee12 e5=new Employee12("ved","Bidadi",56544);
    
    
    m.put(1234567890l, e1);
    m.put(9866502069l, e2);
    m.put(9676565632l, e3);
    m.put(9966502069l, e4);
    m.put(9909802069l, e4);
    
    Set set=m.entrySet();
    Iterator itr=set.iterator();
    
    while(itr.hasNext())
    {
    	
    	Entry entry=(Entry) itr.next();
    	Employee12 emp=(Employee12) entry.getValue();
    	
    	emp.sal=emp.sal+1000;
    	System.out.println(emp);
    	
    }
    
    //System.out.println(m.get(num));    
   
    
    /*  Employee12 e=m.get(num);
        System.out.println(e.sal);

    */

    Employee12 e=m.get(num);
    e.sal=e.sal+1000;
    System.out.println(e.sal);

 
    
    
    
    

}
}
 