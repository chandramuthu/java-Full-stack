class Instat //instance and static difference
{
int var1=123;//instance variable
static int var2= 1234; //Static var

void m1() //instance method
{
	System.out.println("Instance method");
}

static void m2() //static method
{
	System.out.println("Static method");
}

public static void main(String args[])
{
	Instat.m2();
	Instat ins=new Instat(); //object creation
	ins.m1();
	System.out.println(ins.var1);
	System.out.println(Instat.var2);
	}
}
