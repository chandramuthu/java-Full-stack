
class Single {
public static void main(String[] args) 
{ 
    two g = new two(); 
    g.meg(); 
    g.ven(); 
} 
    public void ven() 
    { 
        System.out.println("Hello"); 
    } 
} 
  
class two extends Single {

    public void meg() 
    { 
        System.out.println("Hi"); 
    } 
    
}