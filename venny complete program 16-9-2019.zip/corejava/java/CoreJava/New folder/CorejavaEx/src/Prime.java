public class Prime {
	
}
