package java8Eg;

import java.util.Scanner;
import java.util.function.DoubleToIntFunction;



public class DoubleToIntEx {
    public static void main(String[] args) {
    	DoubleToIntFunction df = (x)->{return(int)x+2;};
    	System.out.println(df.applyAsInt(5.5));
    }

 

}
 
