package java8Eg;

public class ThreadTest {
	public static void main(String[] args) {
		Runnable r = () -> {
			System.out.println(Thread.currentThread());
			for (int i = 0; i <= 5; i++) {
				System.out.println("Child Thread");
			};
		};
				Thread t = new Thread(r);
				t.start();
				for (int i = 0; i <= 5; i++) {
					System.out.println("Main Thread");
				}
				System.out.println(Thread.currentThread());
		
	}
}