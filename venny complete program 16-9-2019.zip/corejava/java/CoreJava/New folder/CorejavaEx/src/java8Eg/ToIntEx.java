package java8Eg;

import java.util.function.ToIntFunction;

public class ToIntEx {
public static void main(String[] args) {
	
	  
	        ToIntFunction<Double> ob = a -> (int)(a * 10); 
	        System.out.println(ob.applyAsInt(3.2)); 
	    }
}
