package java8Eg;

import java.util.function.DoubleToLongFunction;

public class DoubleToLongEx {
	public static void main(String[] args) {
    	DoubleToLongFunction df = (x)->{return(long)x;};
    	System.out.println(df.applyAsLong(598.5));
}
}