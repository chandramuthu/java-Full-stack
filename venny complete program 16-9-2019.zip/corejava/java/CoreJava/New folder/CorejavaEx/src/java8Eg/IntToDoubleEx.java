package java8Eg;

import java.util.function.IntToDoubleFunction;

public class IntToDoubleEx {
	 public static void main(String[] args) {
	        IntToDoubleFunction funcn1=i->i*i;//here the parameters is not not working
	        IntToDoubleFunction funcn2=i->i*i*i;
	        System.out.println("Square of 2 : "+funcn1.applyAsDouble(2));//The given data type is Integer but its return type is Double
	        System.out.println("Cube of 2 : "+funcn2.applyAsDouble(2));
	        System.out.println("Square of 3 : "+funcn1.applyAsDouble(3));
	        System.out.println("Cube of 3 : "+funcn2.applyAsDouble(3));
	    }
}
