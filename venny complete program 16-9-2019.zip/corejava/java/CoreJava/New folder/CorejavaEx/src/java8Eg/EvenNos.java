package java8Eg;

import java.util.function.Predicate;

public class EvenNos {
	public static void main(String[] args) {

		int[] values = { 1, 5, 6, 8, 10, 9, 2 };
		Predicate<Integer> pre=i ->i%2==0; 
		for (int val : values) //until the values provided in the array becomes empty it will iterate 
			if (pre.test(val)) {
				System.out.println(val);
			}
		}
	}

