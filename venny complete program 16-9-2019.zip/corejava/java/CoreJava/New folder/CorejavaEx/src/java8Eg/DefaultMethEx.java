package java8Eg;

interface A{
	void m1();
	default void m2() {
		System.out.println("Interface default method");
	}
	default void m3(){
		System.out.println("Interface default method");
	}
}

public class DefaultMethEx implements A{

	@Override
	public void m1() {
		System.out.println("Test default class method implementation");
		// TODO Auto-generated method stub
		
	}
	@Override
	public void m2(){
		System.out.println("different implementation for interface default");
	}
	
	public static void main(String[] args) {
		
		DefaultMethEx d= new DefaultMethEx();
		d.m1();
		d.m2();
		d.m3();
	}

}
