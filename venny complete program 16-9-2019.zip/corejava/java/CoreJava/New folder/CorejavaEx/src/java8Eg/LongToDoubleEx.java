//package java8Eg;
//
//import java.util.function.LongToDoubleFunction;
//
//public class LongToDoubleEx {
//	 LongToDoubleFunction funcn1=i->i*i;
//     LongToDoubleFunction funcn2=i->i*i*i;
//        
//         System.out.println("Square of 3 : "+funcn1.applyAsDouble(3));
//         System.out.println("Cube of 3 : "+funcn2.applyAsDouble(7));
// }
//
//
//
//
//
