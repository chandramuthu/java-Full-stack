package java8Eg;

import java.util.Comparator;
import java.util.TreeMap;

public class TreeMapEx {

		public static void main(String[] args) {
			Comparator<Integer> c=(i1,i2)-> {return (i1<i2)?-1:0;};
			/*Comparator<Integer> c1=(i1,i2)-> {return -i1.compareTo(i2);};
			comparator<Integer> c2=(i1,i2)-> {return i2.compareTo(i1);};*/
			
			TreeMap<Integer, String> t = new TreeMap<Integer, String>(c);
			t.put(200, "ven");
			t.put(300,"meg");
			t.put(400,"kee");
			t.put(500, "ved");
			System.out.println(t);
		}
}
