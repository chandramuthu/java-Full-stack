package java8Eg;

@FunctionalInterface //takes only one abstract method (here our abstract method :color)
interface Favorite 
{
	public void color();
}

public class FavoriteClr
{
	public static void main(String[] args)
	{
		Favorite f = () -> System.out.println("My favorite color is blue");
		f.color();
	}
}