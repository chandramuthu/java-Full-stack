package java8Eg;

import java.util.function.Consumer;

public class ConsumerEx {
public static void main(String[] args) {
	Consumer <Integer> con=i-> System.out.println(i*i);
	con.accept(123);
	con.accept(789);
			
			
}
}
