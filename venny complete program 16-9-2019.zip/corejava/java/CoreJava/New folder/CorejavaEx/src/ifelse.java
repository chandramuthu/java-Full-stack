
public class ifelse {
 public static void main(String[] args) {
	boolean x=true;
	if(x=false)
	{
		System.out.println("Hello");
	}
	else
	{
		System.out.println("Hi");
	}
}
}
