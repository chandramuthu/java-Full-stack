
class A{
	static void add() {
		System.out.println("default method");
	}
	static void add(int a,int b) 
	{
		System.out.println("Addition of two nos :(int)"+(a+b));
	}
	
	static void add(float a,float b) 
	{
		System.out.println("Addition of two nos :(float)"+(a+b));
	}
	
	static void add(int a,float b) 
	{
		System.out.println("Addition of two nos :(int,float)"+(a+b));
	}
	
	static void add(float a,int b) 
	{
		System.out.println("Addition of two nos :(float,int)"+(a+b));
	}
}
public class Test2 {
	public static void main(String[] args) {
		A.add();
		A.add('c', 'a');
		A.add(12f,123f);
		A.add(12,9f);
		A.add(12f,20);
		
	}
}
