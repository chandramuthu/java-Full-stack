package com.cap;
class A{
	public void m1(){
		System.out.println("public method");
}
}
public class Test {
public int eid=123;
	public static void main(String[] args) {
		A a=new A();
		a.m1();
	}

}
