package ioexample; 
import java.io.IOException;
import java.io.PrintWriter;
public class PrintwriterEx {
	public static void main(String[] args) throws IOException 
	{
		PrintWriter out=new PrintWriter("abc1.txt");
		out.println(1000);
		out.println(false);
		out.println('&');
		out.println("Ven");
		out.flush();
		out.close();
		out.close();
	}
}
