package ioexample;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedStreamEx {
	public static void main(String[] args) throws IOException {
		String filepath="s1.txt";
		
		//1.Create Stream Object
		FileOutputStream fos=new FileOutputStream(filepath); //2bytes
		
		//2.Pass Stream object to bufferStream constructor
		BufferedOutputStream bos=new BufferedOutputStream(fos);//1024 bytes
		String s="oracle.com";
		byte [] b=s.getBytes();
		bos.write(b);
		bos.flush();
		bos.close();
		//1.create stream object
		FileInputStream fis=new FileInputStream(filepath);
		
		//2.Pass Stream object to bufferStream constructor
		BufferedInputStream bis=new BufferedInputStream(fis);
		int i;
		while((i=bis.read())!=-1)
		{
			System.out.print((char)i);
		}
		bis.close();
	}
}
