package ioexample;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class Login {
	public static void main(String[] args) throws IOException
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter user name : ");
		String username = sc.next();
		System.out.println("Enter user Password : ");
		String password = sc.next();
		FileReader fr=new FileReader("abc1.txt");
		BufferedReader dr=new BufferedReader(fr);
		String uname=dr.readLine();
		String passwrd=dr.readLine();
		if (username.equals(uname) && password.equals(passwrd))
		 System.out.println("Success");
		else
		 System.out.println("Login Failed");
		sc.close();
		dr.close();
	}
}
