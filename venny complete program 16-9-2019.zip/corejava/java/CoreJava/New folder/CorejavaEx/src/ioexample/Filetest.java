package ioexample;
import java.io.*;
public class Filetest {
	public static void main(String[] args) throws IOException {
		File f=new File("myfolder2/myfolder1/file.txt");
		f.getParentFile().mkdirs();
		f.createNewFile();
		System.out.println("done  "+f.getAbsolutePath());
	}
}
