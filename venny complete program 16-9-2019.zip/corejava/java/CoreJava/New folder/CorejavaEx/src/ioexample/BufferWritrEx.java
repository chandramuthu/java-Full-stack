package ioexample;
import java.io.*;
public class BufferWritrEx {
	public static void main(String[] args) throws IOException  
	{
		FileWriter fw=new FileWriter("abc.txt"); //it will create 
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write(97);//charecter
		bw.newLine();
		
		char[] ch1={'a','b','c','d'};
		bw.write(ch1);
		bw.newLine();
		bw.write("Welcome");
		bw.newLine();
		bw.write("Home");
		bw.flush();
		bw.close();
		bw.close();
	}
}
