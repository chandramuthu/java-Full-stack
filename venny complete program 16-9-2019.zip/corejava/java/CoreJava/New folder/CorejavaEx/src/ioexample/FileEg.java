package ioexample;
import java.io.*;
public class FileEg {
	public static void main(String[] args) throws IOException {
		File f=new File("capgeminiemp/emp.txt");
		f.getParentFile().mkdir();
		f.createNewFile();
		System.out.println("Done");
	}
}
