package ioexample;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderEx
{
 public static void main(String[] args) throws IOException
 {
	FileReader fr1=new FileReader("abc1.txt");
	int i=fr1.read();
	while(i !=-1) //eof the file ==> -1
	{
		System.out.println((char)i);
		i=fr1.read();		
	}
	
	System.out.println("****************************************");
	fr1.close();
 }
}
