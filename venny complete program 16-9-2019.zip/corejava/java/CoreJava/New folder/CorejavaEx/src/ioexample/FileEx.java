package ioexample;

import java.io.File;

import java.io.IOException;

public class FileEx
{

	public static void main(String[] args) throws IOException 
	{
		File f=new File("cap.txt");
		
		System.out.println(f.exists());//true
		
		System.out.println(f.createNewFile());//false
		
		System.out.println(f.exists());//true
		
		System.out.println(f.isDirectory());//false
		
		System.out.println(f.isFile());//true
		
		f.createNewFile();
		
		System.out.println("Created");
	}
}
