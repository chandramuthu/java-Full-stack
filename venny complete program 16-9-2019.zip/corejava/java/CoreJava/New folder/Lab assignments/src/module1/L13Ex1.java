package module1;

@FunctionalInterface
interface Power {



   public double power(int x,int y);
}
public class L13Ex1 {
	  public static void main(String[] args) {
		    
	        Power i1 = (x,y)->{return Math.pow(x,y);};
	        System.out.println("2 to the power 3 is "+i1.power(2,3));
	    }
}
