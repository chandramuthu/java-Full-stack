package com.cap;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateEx {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		{
			// 5 steps +1
			// step 1 loading the driver class --> Oracle Driver
			Class.forName("oracle.jdbc.driver.OracleDriver"); // ojdbc jar
			// step 2 : Create the connection
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "ven", "capgemini");
			// step 3: create the statement
			Statement stmt = conn.createStatement();
			// step 4:execute query
			@SuppressWarnings("unused")
			boolean val = stmt.execute("Create table employeenew(empid number, empname varchar (20))");
			System.out.println("table Created");

			// ddl --> execute() --> boolean
			// dml -->executeUpdate -->int
			// drl -->executeQuery -->ResultSet
			// step 5: close the connection
			conn.close();
		}
	}
}
