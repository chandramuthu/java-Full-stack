package jdbcproject1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	//step-1 loading the driver class----> Oracle Driver
	Class.forName("oracle.jdbc.driver.OracleDriver");
	// step-2 create the Connection
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "chandra", "muthu");
	//step-3 create the statement
	Statement stmt=conn.createStatement();
	//step-4 Execute Query
	boolean val=stmt.execute("create table cm(cmid number(10),cmname varchar2(20))");
	System.out.println("Sql query executed  "+val);
	//step-5 Close the connection
	conn.close();
}
}
