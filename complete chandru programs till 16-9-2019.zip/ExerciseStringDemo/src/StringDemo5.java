import java.util.Scanner;

public class StringDemo5 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a sentence: ");
	String str=sc.nextLine();
	
		String MA[]= str.split(" ");          
		System.out.println("The numbers of words present in this sentence is: "+ MA.length);
	
}
}

