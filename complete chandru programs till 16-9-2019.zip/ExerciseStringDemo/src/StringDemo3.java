
public class StringDemo3 {
public static void main(String[] args) {
	{
		String str1 ="Chandra muthu v";
		
		String str2 ="Chandra muthu v";
		System.out.println(str1.matches(str2));
     }
}
}
