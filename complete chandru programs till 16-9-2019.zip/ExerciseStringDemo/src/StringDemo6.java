import java.util.Scanner;

public class StringDemo6 {

	 public static void main(String args[])
	 {
	      Scanner in = new Scanner(System.in);
	      String s = "";
	      System.out.print("Please give a string: ");
	      String str = in.nextLine();
	      int z = str.length();
	      for(int y = 0; y < z; y++)
	      {
	         if(Character.isUpperCase(str.charAt(y))){
	            char w = str.charAt(y);
	           s = s + w + " ";
	         }
	      }
	      System.out.println("The uppercase characters are " + s);
	      //Uppercase
	   }
}

