import java.util.Scanner;

public class StringDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the String: ");
		String name=sc.nextLine();
		System.out.print("Enter the index value: ");
		int index=sc.nextInt();
		System.out.print("The Character of a given index is: "+name.charAt(index));
}
}



