package accessspecifier;

public class Test {
	public static int a=10;
	protected static int b=20;
	protected int c=15;
public static void main(String[] args) {
	
	
}
}
