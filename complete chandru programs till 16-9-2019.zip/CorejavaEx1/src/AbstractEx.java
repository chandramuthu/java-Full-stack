
class AbstractEx {
public static void main(String[] args) {
	Test1 t=new Test1();
	t.setEmpid(10);
	t.setAtmpin(7773);
	t.setEmpsal(10000);
	t.setName("vijay");
	
	System.out.println(t.getEmpid());
	System.out.println(t.getEmpsal());
	System.out.println(t.getName());
	

}
}
