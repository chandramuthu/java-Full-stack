
public class ConsumerAndAcceptEx {
public static void main(String[] args) {
	
}
}
