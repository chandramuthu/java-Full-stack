package collectionsDemo;
import java.util.*;
public class EmployeeTest {
public static void main(String[] args) {
	
}
}
