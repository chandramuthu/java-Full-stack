package MultiThreadingDemo;
class Tex extends Thread
{
	
}



public class MultiThreadingUsingJoin {
public static void main(String[] args) {
	
	
	
}
}
