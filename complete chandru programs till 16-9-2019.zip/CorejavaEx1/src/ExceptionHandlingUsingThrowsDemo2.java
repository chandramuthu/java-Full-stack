
@SuppressWarnings("serial")
class MyException12 extends Exception
{
	public MyException12(String errormsg)
	{
		super(errormsg);
	}
}
public class ExceptionHandlingUsingThrowsDemo2 
{
	static void validation1(String age1) throws MyException12
	{
		if(age1=="CM")
		{
			try {
				throw new MyException12("You have typed invalid name");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("Valid Name");
		}
	}
public static void main(String[] args) throws MyException12
{
	try {
		ExceptionHandlingUsingThrowsDemo2.validation1("CM");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Rest of the code is being executed");
}
}
