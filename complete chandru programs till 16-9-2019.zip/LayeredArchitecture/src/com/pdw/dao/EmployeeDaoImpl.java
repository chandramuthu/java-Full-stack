package com.pdw.dao;

import java.util.HashMap;
import java.util.Map;

import com.pdw.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	Map<Integer,Employee> employees=new HashMap<Integer,Employee>();

	@Override
	public Employee insertEmployee(Employee employee) {
	return employees.put(employee.getEmpId(), employee);
	
	}

	@Override
	public Employee retrieveEmployee(Integer eid) {
		// TODO Auto-generated method stub
		return employees.get(eid);
	}
	
	
	
	

}
