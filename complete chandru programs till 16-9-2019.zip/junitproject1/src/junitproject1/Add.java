package junitproject1;

public class Add {
int sum(int a, int b)
{
	return a+b;
}
}
