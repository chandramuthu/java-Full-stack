package junitproject1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class JunitTestCase1 {

	@Test
	public void m1() {
		System.out.println("Test Case 1");
	}
	@Before
	public  void m2() {
		System.out.println("Executes before all test classes");
	}
	@BeforeClass
	public static void m3() {
		System.out.println("Executes one time and first");
	}
	@Test
	public void m4() {
		System.out.println("Test case2");
	}
	@After
	public void m5() {
		System.out.println("Executed after every test classes");
	}
	@AfterClass
	public static void m6() {
		System.out.println("Executes only one time and at last");
	}
	@Ignore
	public void m7() {
		System.out.println("Im being ignored");
	}

}
