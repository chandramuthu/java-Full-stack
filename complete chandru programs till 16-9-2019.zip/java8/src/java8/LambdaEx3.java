package java8;

import java.util.Scanner;

interface cm
{
	public int square(int num);
}
public class LambdaEx3 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	while(true)
	{
	System.out.println("Enter the Number");
	int n=sc.nextInt();
	cm c=num->n*n;
	System.out.println("the square of "+n+" is:  "+c.square(n));
	
	}
}
}
