package java8;

import java.util.Scanner;

interface calci1
{
	public int length(String a);

}
public class LambdaExp1 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter thye String to find length");
	String x=sc.next();
	
	
	calci1 f=a->a.length();
	System.out.println("Length of "+x+"  = "+f.length(x));
	sc.close();
}
}
