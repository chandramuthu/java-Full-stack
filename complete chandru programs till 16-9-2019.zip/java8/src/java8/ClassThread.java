package java8;

public class ClassThread {
public static void main(String[] args) throws Throwable {
	Runnable r=()->{
		System.out.println(Thread.currentThread());
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread");
		}
	};
	Thread t=new Thread(r);
	t.start();
	Thread.sleep(1000);
	for(int i=0;i<5;i++)
	{
		System.out.println("Main Thread");
	}
	System.out.println(Thread.currentThread());
	
}
}
