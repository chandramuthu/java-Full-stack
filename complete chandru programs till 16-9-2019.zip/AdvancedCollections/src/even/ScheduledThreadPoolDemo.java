package even;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduledThreadPoolDemo {
public static void main(String[] args) {
	ScheduledExecutorService service=Executors.newScheduledThreadPool(100);
	//service.schedule(new Task2(), 3,TimeUnit.SECONDS);
	//service.scheduleAtFixedRate(new Task2(),3, 3,TimeUnit.SECONDS);

	service.scheduleWithFixedDelay(new Task2(),3, 3,TimeUnit.SECONDS);
}
}
class Task2 implements Runnable
{
	public void run()
	{
		Date date=new Date();
		System.out.println("Hi"+Thread.currentThread().getName()+" "+ new SimpleDateFormat("HH:mm:ss").format(date));
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			Thread.sleep(1000);
			
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
