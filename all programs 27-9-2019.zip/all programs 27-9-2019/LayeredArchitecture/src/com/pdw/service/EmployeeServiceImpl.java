package com.pdw.service;

import com.pdw.bean.Employee;
import com.pdw.dao.EmployeeDao;
import com.pdw.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao dao=new EmployeeDaoImpl() {
	};
	@Override
	public Employee insertEmployee(Employee employee) {
		return dao.insertEmployee(employee);
	}

	@Override
	public Employee retrieveEmployee(Integer eid) {
		return dao.retrieveEmployee(eid);
	}

}
