package com.pdw.service;

import com.pdw.bean.Employee;

public interface EmployeeService {
Employee insertEmployee(Employee employee);
Employee retrieveEmployee(Integer eid);
}
//service