package lab8;

import java.util.StringTokenizer;

public class Ex7 {
	public boolean registeringUserName(String s) {
		if (s.endsWith("_job")) {
			StringTokenizer st = new StringTokenizer(s, "_job");
			int a = st.nextToken().length();
			if (a > 8) {
				System.out.println(a);
				return true;
			} else {
				System.out.println(a);
				return false;
			}
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		Ex7 obj = new Ex7();
		System.out.println(obj.registeringUserName("Chandra muthu_job"));
	}

}
