
public class StringDemo8 {
public static void main(String[] args) {
	String str="b.v.raju college";
	String str1;
	str1=str.replace(str.substring(4,8),str.substring(4,8).toUpperCase()); 
	System.out.println(str1);

}
}
