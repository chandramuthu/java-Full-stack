package java8;

import java.util.Scanner;

interface calci
{
	public int add1(int a, int b);
}


public class LambdaExp {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter First Number");
	int x=sc.nextInt();
	System.out.println("Enter Second Number");
	int y=sc.nextInt();
	
	calci f=(a,b)->a+b;
	System.out.println("Addition of "+x+" and "+y+" = "+f.add1(x, y));
	sc.close();
}
}
