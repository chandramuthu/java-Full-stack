package collectionsDemo;

import java.util.HashSet;

public class HashSetDemo {
public static void main(String[] args) {
	HashSet h= new HashSet();
	h.add(10);
	h.add("asfsafs");
	h.add("gdghfghf");
	h.add(20);
	h.add('c');
	System.out.println(h);
}
}
