package collectionsDemo;

public interface comparable {

}
