import java.util.Scanner;

public class Tempsimply {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<3;i++){
	System.out.println("Enter pasword");
	int n=sc.nextInt();
	System.out.println("Enter Name");
	String s=sc.nextLine();
	}
}
}
