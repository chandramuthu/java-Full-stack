import org.junit.Assert;
import org.junit.Test;

 


 

public class TestEbBill {
  

 

    @Test
    public void cm() {
    	EbBill e=new EbBill(101, "swathi", 150, 20);
    	double d=e.calculateBill();
    	double expectedOutput=1000.0;
    	System.out.println("Tested succesfully!!");
        Assert.assertEquals(expectedOutput, d);
        
        
    }

}

