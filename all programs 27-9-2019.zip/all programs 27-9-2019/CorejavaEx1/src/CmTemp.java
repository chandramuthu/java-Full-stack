  public class CmTemp {
      public static void main(String [] args) {
         short a,b;
         int c=0;
         a=1;
         b=2;
         double a1=20;
         c= (a+b);
         System.out.println(a1);
      }
  }
  