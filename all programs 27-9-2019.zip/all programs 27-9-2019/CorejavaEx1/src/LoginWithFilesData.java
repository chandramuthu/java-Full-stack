

public class LoginWithFilesData {
}
