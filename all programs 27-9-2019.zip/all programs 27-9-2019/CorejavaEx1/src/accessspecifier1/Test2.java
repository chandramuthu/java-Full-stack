package accessspecifier1;
import accessspecifier.Test;

public class Test2 extends Test {
public static void main(String[] args) {

	System.out.println(+a);
	System.out.println(Test.b);
	Test2 t=new Test2();
	int d = t.c;
	System.out.println(+d);
	
	
}
}
