
public class Test1
{
private int empid;
private int empsal;
private String name;
private int atmpin;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public int getEmpsal() {
	return empsal;
}
public void setEmpsal(int empsal) {
	this.empsal = empsal;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


public void setAtmpin(int atmpin) {
	this.atmpin = atmpin;
}



}
