
public class EbBill {
	private int billNo;
	private String consumerName;
	private int unitsConsumed;
	private double  perUnitCost;
public EbBill(int billNo, String consumerName, int unitsConsumed, double perUnitCost) {
		super();
		this.billNo = billNo;
		this.consumerName = consumerName;
		this.unitsConsumed = unitsConsumed;
		this.perUnitCost = perUnitCost;
	}
public double calculateBill()
{
	if(unitsConsumed>=0 && unitsConsumed<=100)
		return 0;
	else
		unitsConsumed=unitsConsumed-100;
		return (unitsConsumed*perUnitCost);	
}
public static void main(String[] args) {
	EbBill b=new EbBill(100, "cm", 120, 60);
	System.out.println("Bill No.: "+b.billNo);
	System.out.println("Bill Amount: "+b.calculateBill());
}
}
