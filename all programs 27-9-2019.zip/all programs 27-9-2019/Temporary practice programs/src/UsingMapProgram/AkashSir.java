package UsingMapProgram;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;



public class AkashSir {
	int eid;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public AkashSir(int eid, int esal) {
		super();
		this.eid = eid;
		this.esal = esal;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	@Override
	public String toString() {
		return "AkashSir [eid=" + eid + ", esal=" + esal + "]";
	}
	int esal;
public static void main(String[] args) {
	
	Map<Integer,Integer> emp=new HashMap<Integer,Integer>();
//	AkashSir a1=new AkashSir(1,10000);
//	AkashSir a2=new AkashSir(2,1001);
//	AkashSir a3=new AkashSir(3,2000);
//	AkashSir a4=new AkashSir(4,3000);
//	AkashSir a5=new AkashSir(5,4000);
	emp.put(1,1000);
	emp.put(2,2000);
	emp.put(3,3000);
	emp.put(4,4000);
	emp.put(5,5000);
	emp.put(6,6000);
	
	Set<Integer> s=emp.keySet();
	Iterator<Integer> itr= s.iterator();
	while(itr.hasNext())
	{
		
		 int k= itr.next();
		Integer val= emp.get(k);
		if(val>1000 && val<=5000)
		{
		System.out.println(val);
		}
		
	}
			
}
}
